window.tinyMCEPreInit = {"base":"\/drupal\/sites\/all\/libraries\/tinymce\/jscripts\/tiny_mce","suffix":"","query":""};;
